package br.com.agendatelefonica.view;

import br.com.agendatelefonica.dao.ContatoDAO;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import br.com.agendatelefonica.model.Contato;

public class TelaAgenda extends JFrame {

    private final ContatoDAO dao = new ContatoDAO();

    private final JTextField txtId = new JTextField(5);
    private final JTextField txtNome = new JTextField(25);
    private final JTextField txtTelefone = new JTextField(15);
    private final JTextField txtEmail = new JTextField(25);
    private final JComboBox<String> cmbCategoria = new JComboBox<>(
            new String[]{"Família", "Trabalho", "Amigos", "Outros"});
    private final JTextField txtBusca = new JTextField(20);

    private final JButton btnNovo = new JButton("Novo/Limpar");
    private final JButton btnSalvar = new JButton("Salvar");
    private final JButton btnEditar = new JButton("Editar");
    private final JButton btnExcluir = new JButton("Excluir");
    private final JButton btnBuscar = new JButton("Buscar");

    private final DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"ID", "Nome", "Telefone", "E-mail", "Categoria"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabela = new JTable(modelo);

    public TelaAgenda() {
        super("Agenda Telefônica");
        montarTela();
        configurarEventos();
        carregarTabela(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    private void montarTela() {
        txtId.setEditable(false);

        // Formulário
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Dados do contato"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 4, 4, 4);
        g.anchor = GridBagConstraints.WEST;

        adicionar(form, g, 0, "ID:", txtId);
        adicionar(form, g, 1, "Nome:", txtNome);
        adicionar(form, g, 2, "Telefone:", txtTelefone);
        adicionar(form, g, 3, "E-mail:", txtEmail);
        adicionar(form, g, 4, "Categoria:", cmbCategoria);

        // Botões
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER));
        botoes.add(btnNovo);
        botoes.add(btnSalvar);
        botoes.add(btnEditar);
        botoes.add(btnExcluir);

        // Busca
        JPanel busca = new JPanel(new FlowLayout(FlowLayout.LEFT));
        busca.setBorder(BorderFactory.createTitledBorder("Pesquisar por nome"));
        busca.add(txtBusca);
        busca.add(btnBuscar);

        JPanel topo = new JPanel(new BorderLayout());
        topo.add(form, BorderLayout.NORTH);
        topo.add(botoes, BorderLayout.CENTER);
        topo.add(busca, BorderLayout.SOUTH);

        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane rolagem = new JScrollPane(tabela);
        rolagem.setPreferredSize(new java.awt.Dimension(600, 200));

        JPanel raiz = new JPanel(new BorderLayout(8, 8));
        raiz.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        raiz.add(topo, BorderLayout.NORTH);
        raiz.add(rolagem, BorderLayout.CENTER);
        setContentPane(raiz);
    }

    private void adicionar(JPanel p, GridBagConstraints g, int linha, String rotulo,
            java.awt.Component campo) {
        g.gridy = linha;
        g.gridx = 0;
        p.add(new JLabel(rotulo), g);
        g.gridx = 1;
        p.add(campo, g);
    }

    private void configurarEventos() {
        btnNovo.addActionListener(e -> limpar());
        btnSalvar.addActionListener(e -> salvar());
        btnEditar.addActionListener(e -> editar());
        btnExcluir.addActionListener(e -> excluir());
        btnBuscar.addActionListener(e -> carregarTabela(txtBusca.getText().trim()));

        // Busca em tempo real
        txtBusca.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                carregarTabela(txtBusca.getText().trim());
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                carregarTabela(txtBusca.getText().trim());
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                carregarTabela(txtBusca.getText().trim());
            }
        });

        // Clique na linha preenche os campos
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                preencherCampos();
            }
        });
    }

    private void carregarTabela(String filtro) {
        try {
            List<Contato> lista = (filtro == null || filtro.isEmpty())
                    ? dao.listar()
                    : dao.pesquisar(filtro);
            modelo.setRowCount(0);
            for (Contato c : lista) {
                modelo.addRow(new Object[]{c.getId(), c.getNome(), c.getTelefone(),
                    c.getEmail(), c.getCategoria()});
            }
        } catch (SQLException ex) {
            erro("Erro ao carregar contatos: " + ex.getMessage());
        }
    }

    private void preencherCampos() {
        int linha = tabela.getSelectedRow();
        if (linha < 0) {
            return;
        }
        txtId.setText(String.valueOf(modelo.getValueAt(linha, 0)));
        txtNome.setText(texto(modelo.getValueAt(linha, 1)));
        txtTelefone.setText(texto(modelo.getValueAt(linha, 2)));
        txtEmail.setText(texto(modelo.getValueAt(linha, 3)));
        String cat = texto(modelo.getValueAt(linha, 4));
        if (!cat.isEmpty()) {
            cmbCategoria.setSelectedItem(cat);
        }
    }

    private void limpar() {
        txtId.setText("");
        txtNome.setText("");
        txtTelefone.setText("");
        txtEmail.setText("");
        cmbCategoria.setSelectedIndex(0);
        tabela.clearSelection();
        txtNome.requestFocus();
    }

    private boolean validar() {
        if (txtNome.getText().trim().isEmpty() || txtTelefone.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nome e telefone são obrigatórios.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private Contato lerCampos() {
        Contato c = new Contato(
                txtNome.getText().trim(),
                txtTelefone.getText().trim(),
                txtEmail.getText().trim(),
                (String) cmbCategoria.getSelectedItem());
        if (!txtId.getText().isEmpty()) {
            c.setId(Integer.parseInt(txtId.getText()));
        }
        return c;
    }

    private void salvar() {
        if (!txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Este contato já existe. Use Editar para alterar ou Novo/Limpar para cadastrar outro.",
                    "Atenção", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (!validar()) {
            return;
        }
        try {
            dao.cadastrar(lerCampos());
            limpar();
            carregarTabela(txtBusca.getText().trim());
            JOptionPane.showMessageDialog(this, "Contato cadastrado com sucesso!");
        } catch (SQLException ex) {
            erro("Erro ao salvar: " + ex.getMessage());
        }
    }

    private void editar() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione um contato na tabela.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!validar()) {
            return;
        }
        try {
            dao.atualizar(lerCampos());
            limpar();
            carregarTabela(txtBusca.getText().trim());
            JOptionPane.showMessageDialog(this, "Contato atualizado com sucesso!");
        } catch (SQLException ex) {
            erro("Erro ao atualizar: " + ex.getMessage());
        }
    }

    private void excluir() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecione um contato na tabela.",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int opcao = JOptionPane.showConfirmDialog(this, "Deseja excluir este contato?",
                "Confirmar exclusão", JOptionPane.YES_NO_OPTION);
        if (opcao != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            dao.excluir(Integer.parseInt(txtId.getText()));
            limpar();
            carregarTabela(txtBusca.getText().trim());
        } catch (SQLException ex) {
            erro("Erro ao excluir: " + ex.getMessage());
        }
    }

    private String texto(Object o) {
        return o == null ? "" : o.toString();
    }

    private void erro(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Erro", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TelaAgenda().setVisible(true));
    }
}
