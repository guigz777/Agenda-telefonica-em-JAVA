package br.com.agendatelefonica.dao;

import br.com.agendatelefonica.conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import br.com.agendatelefonica.model.Contato;

public class ContatoDAO {

    // CREATE
    public void cadastrar(Contato c) throws SQLException {
        String sql = "INSERT INTO contatos (nome, telefone, email, categoria) VALUES (?, ?, ?, ?)";
        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNome());
            ps.setString(2, c.getTelefone());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getCategoria());
            ps.executeUpdate();
        }
    }

    // READ - todos
    public List<Contato> listar() throws SQLException {
        String sql = "SELECT * FROM contatos ORDER BY nome";
        List<Contato> lista = new ArrayList<>();
        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(montar(rs));
            }
        }
        return lista;
    }

    // READ - pesquisa por nome
    public List<Contato> pesquisar(String nome) throws SQLException {
        String sql = "SELECT * FROM contatos WHERE nome LIKE ? ORDER BY nome";
        List<Contato> lista = new ArrayList<>();
        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + nome + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(montar(rs));
                }
            }
        }
        return lista;
    }

    // UPDATE
    public void atualizar(Contato c) throws SQLException {
        String sql = "UPDATE contatos SET nome = ?, telefone = ?, email = ?, categoria = ? WHERE id = ?";
        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNome());
            ps.setString(2, c.getTelefone());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getCategoria());
            ps.setInt(5, c.getId());
            ps.executeUpdate();
        }
    }

    // DELETE
    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM contatos WHERE id = ?";
        try (Connection con = Conexao.getConexao();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private Contato montar(ResultSet rs) throws SQLException {
        return new Contato(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("telefone"),
                rs.getString("email"),
                rs.getString("categoria"));
    }
}
