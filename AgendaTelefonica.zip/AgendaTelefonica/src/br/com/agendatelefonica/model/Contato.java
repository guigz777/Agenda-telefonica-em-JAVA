package br.com.agendatelefonica.model;

public class Contato {

    private int id;
    private String nome;
    private String telefone;
    private String email;
    private String categoria;

    public Contato() {
    }

    public Contato(String nome, String telefone, String email, String categoria) {
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
        this.categoria = categoria;
    }

    public Contato(int id, String nome, String telefone, String email, String categoria) {
        this(nome, telefone, email, categoria);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}
